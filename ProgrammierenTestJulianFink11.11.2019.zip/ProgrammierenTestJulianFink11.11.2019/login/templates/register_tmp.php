<div id="register" >
    <form id="form" action="register.php" method="POST">
        <a  onclick="openRegister()" id="close">&times;</a>
        <img src="Images/login_icon.png" alt="Login-Icon">
        <input class="input register" type="text" name="uname" required placeholder="Username">
        <input class="input register" type="password" name="password" required placeholder="Password">
        <input class="input register" type="password"name="password2"  required placeholder="Confirm Password">
        <input class="input register" type="submit" value="Register">
        <a href="#" class="text" onclick="openRegister()">Need some help?</a>
    </form>
</div>
